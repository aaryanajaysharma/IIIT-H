mirrms('Folder', 'Frame', 0.05, 0.5);
%% 
miraudio('Folder', 'Sampling', 3);
%% 
t = mirtempo('Folder', 'Frame', 3, 1.5);
k = mirkey('Folder', 'Frame', 3, 1.5);
%% 
miraudio('Folder', 'Sampling', 3);
%%
