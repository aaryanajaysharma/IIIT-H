module.exports = {
  apps: [
    {
      name: 'strapi-chotu', // Your project name
      cwd: '/home/ubuntu/DASS2k23-Team-13', // Path to your project
      script: 'npm', // For this example we're using npm, could also be yarn
      args: 'run develop', // Script to start the Strapi server, `start` by default
      env: {
        APP_KEYS: 'TaLDXtXCA10/RwxdX6btaw==,l0I4O16tdz09TdTkiyDtUw==,QxPEV8mn26GO1hzHVU4a6w==,bA0pwToTviVOy0yG/F9sQw==', // you can find it in your project .env file.
        API_TOKEN_SALT: '5meUB63IFfBG+Xp+2MxNvQ==',
        ADMIN_JWT_SECRET: 'nC5LeMx6eocyeH67WaOyoQ==',
        JWT_SECRET: 'nC5LeMx6eocyeH67WaOyoQ==',
        NODE_ENV: 'production',
        DATABASE_HOST: 'strapi-database.cs4hdqu8dvof.ap-northeast-1.rds.amazonaws.com', // database Endpoint under 'Connectivity & Security' tab
        DATABASE_PORT: '3306',
        DATABASE_NAME: 'strapi', // DB name under 'Configuration' tab
        DATABASE_USERNAME: 'strapi_mysql', // default username
        DATABASE_PASSWORD: 'bMPZtkcpM6PxnWA',
        AWS_ACCESS_KEY_ID: 'AKIAUF4KKQCZ4Z5AEAG7',
        AWS_ACCESS_SECRET: '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', // Find it in Amazon S3 Dashboard
        AWS_REGION: 'ap-northeast-1',
        AWS_BUCKET_NAME: 'chotu-strapi-images',
      },
    },
  ],
};
