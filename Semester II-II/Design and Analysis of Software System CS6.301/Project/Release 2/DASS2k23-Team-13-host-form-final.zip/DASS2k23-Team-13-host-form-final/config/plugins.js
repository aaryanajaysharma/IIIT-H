module.exports = ({ env }) => ({
  upload: {
    config: {
      provider: 'aws-s3',
      providerOptions: {
        accessKeyId: env('AKIAUF4KKQCZ4Z5AEAG7'),
        secretAccessKey: env('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'),
        region: env('ap-northeast-1a'),
        params: {
            Bucket: env('chotu-strapi-images'),
        },
      },
      // These parameters could solve issues with ACL public-read access — see [this issue](https://github.com/strapi/strapi/issues/5868) for details
      actionOptions: {
        upload: {
          ACL: null
        },
        uploadStream: {
          ACL: null
        },
      }
   
    },
	  
  },
  'ez-forms': {
    enabled: true,
    resolve: './src/plugins/ez-forms'
  }, 	
});
