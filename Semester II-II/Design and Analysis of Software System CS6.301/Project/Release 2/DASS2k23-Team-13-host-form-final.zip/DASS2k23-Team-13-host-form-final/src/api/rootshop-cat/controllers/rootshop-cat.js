'use strict';

/**
 * rootshop-cat controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::rootshop-cat.rootshop-cat');
