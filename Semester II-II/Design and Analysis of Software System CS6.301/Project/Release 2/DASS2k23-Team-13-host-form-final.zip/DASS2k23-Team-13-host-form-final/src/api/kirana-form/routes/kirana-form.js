'use strict';

/**
 * kirana-form router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::kirana-form.kirana-form');
