'use strict';

/**
 * rootshop-tag service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::rootshop-tag.rootshop-tag');
