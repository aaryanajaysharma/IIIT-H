'use strict';

/**
 * rootshop-meta controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::rootshop-meta.rootshop-meta');
