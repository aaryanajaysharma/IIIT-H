'use strict';

/**
 * captain-meta controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::captain-meta.captain-meta');
