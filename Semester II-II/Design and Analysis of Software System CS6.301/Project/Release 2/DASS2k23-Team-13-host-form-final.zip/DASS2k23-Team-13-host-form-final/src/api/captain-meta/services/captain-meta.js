'use strict';

/**
 * captain-meta service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::captain-meta.captain-meta');
