'use strict';

/**
 * bakery-form2 controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::bakery-form2.bakery-form2');
