'use strict';

/**
 * trial-form router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::trial-form.trial-form');
