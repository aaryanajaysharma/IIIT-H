'use strict';

/**
 * bakery-form2 service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::bakery-form2.bakery-form2');
