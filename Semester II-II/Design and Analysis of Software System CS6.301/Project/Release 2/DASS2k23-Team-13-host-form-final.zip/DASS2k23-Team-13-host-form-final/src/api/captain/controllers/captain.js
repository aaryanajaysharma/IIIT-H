'use strict';

/**
 * captain controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::captain.captain');
