'use strict';

/**
 * kirana-form2 controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::kirana-form2.kirana-form2');
