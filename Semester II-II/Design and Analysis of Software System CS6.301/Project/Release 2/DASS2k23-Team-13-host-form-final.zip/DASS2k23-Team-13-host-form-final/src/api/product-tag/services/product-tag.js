'use strict';

/**
 * product-tag service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::product-tag.product-tag');
