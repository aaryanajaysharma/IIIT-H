'use strict';

/**
 * ticket-booking controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::ticket-booking.ticket-booking');
