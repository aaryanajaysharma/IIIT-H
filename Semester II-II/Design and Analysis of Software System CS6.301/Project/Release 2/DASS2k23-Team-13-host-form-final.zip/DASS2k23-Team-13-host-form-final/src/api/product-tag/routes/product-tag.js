'use strict';

/**
 * product-tag router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::product-tag.product-tag');
