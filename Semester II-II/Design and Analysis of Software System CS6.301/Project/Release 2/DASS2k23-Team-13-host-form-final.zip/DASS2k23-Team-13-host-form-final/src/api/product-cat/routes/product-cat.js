'use strict';

/**
 * product-cat router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::product-cat.product-cat');
