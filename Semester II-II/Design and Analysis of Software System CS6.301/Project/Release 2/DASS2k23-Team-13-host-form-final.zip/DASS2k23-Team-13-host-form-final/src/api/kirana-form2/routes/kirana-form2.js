'use strict';

/**
 * kirana-form2 router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::kirana-form2.kirana-form2');
