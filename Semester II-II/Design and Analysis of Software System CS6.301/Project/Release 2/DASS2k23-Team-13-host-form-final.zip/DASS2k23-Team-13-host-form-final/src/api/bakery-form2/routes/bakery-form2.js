'use strict';

/**
 * bakery-form2 router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::bakery-form2.bakery-form2');
