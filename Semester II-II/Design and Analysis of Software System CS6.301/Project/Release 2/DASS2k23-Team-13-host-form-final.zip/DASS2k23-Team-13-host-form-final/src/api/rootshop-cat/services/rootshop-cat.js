'use strict';

/**
 * rootshop-cat service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::rootshop-cat.rootshop-cat');
