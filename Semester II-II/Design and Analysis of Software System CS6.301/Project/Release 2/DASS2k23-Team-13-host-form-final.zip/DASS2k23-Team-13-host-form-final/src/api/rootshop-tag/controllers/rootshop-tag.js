'use strict';

/**
 * rootshop-tag controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::rootshop-tag.rootshop-tag');
