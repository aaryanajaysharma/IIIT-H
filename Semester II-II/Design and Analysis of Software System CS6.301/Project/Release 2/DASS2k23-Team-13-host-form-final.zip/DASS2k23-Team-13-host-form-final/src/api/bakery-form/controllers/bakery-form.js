'use strict';

/**
 * bakery-form controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::bakery-form.bakery-form');
