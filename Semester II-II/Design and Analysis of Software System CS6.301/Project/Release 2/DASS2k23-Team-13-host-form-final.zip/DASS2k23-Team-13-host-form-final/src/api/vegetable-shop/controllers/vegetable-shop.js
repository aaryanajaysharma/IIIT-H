'use strict';

/**
 * vegetable-shop controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::vegetable-shop.vegetable-shop');
