'use strict';

/**
 * vegetable-shop router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::vegetable-shop.vegetable-shop');
