'use strict';

/**
 * kirana-form controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::kirana-form.kirana-form');
