'use strict';

/**
 * kirana-form2 service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::kirana-form2.kirana-form2');
