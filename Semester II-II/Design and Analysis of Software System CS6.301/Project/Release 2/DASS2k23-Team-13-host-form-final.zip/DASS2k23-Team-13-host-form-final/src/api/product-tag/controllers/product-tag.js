'use strict';

/**
 * product-tag controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::product-tag.product-tag');
