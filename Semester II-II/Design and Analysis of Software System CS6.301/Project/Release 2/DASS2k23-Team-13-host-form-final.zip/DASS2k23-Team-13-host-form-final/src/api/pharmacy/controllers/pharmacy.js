'use strict';

/**
 * pharmacy controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::pharmacy.pharmacy');
