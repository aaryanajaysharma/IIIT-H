'use strict';

/**
 * rootshop-tag router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::rootshop-tag.rootshop-tag');
