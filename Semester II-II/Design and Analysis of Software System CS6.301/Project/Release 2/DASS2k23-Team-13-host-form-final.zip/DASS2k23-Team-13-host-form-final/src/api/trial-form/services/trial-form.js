'use strict';

/**
 * trial-form service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::trial-form.trial-form');
