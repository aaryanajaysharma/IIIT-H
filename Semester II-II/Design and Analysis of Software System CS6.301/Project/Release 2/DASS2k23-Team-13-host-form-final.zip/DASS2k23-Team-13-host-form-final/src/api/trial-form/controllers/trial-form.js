'use strict';

/**
 * trial-form controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::trial-form.trial-form');
