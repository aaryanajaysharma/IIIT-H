'use strict';

/**
 * ticket-booking router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::ticket-booking.ticket-booking');
