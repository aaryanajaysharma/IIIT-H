'use strict';

/**
 * product-cat controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::product-cat.product-cat');
