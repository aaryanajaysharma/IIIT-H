'use strict';

/**
 * bakery-form router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::bakery-form.bakery-form');
