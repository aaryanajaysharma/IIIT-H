'use strict';

/**
 * kirana-form service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::kirana-form.kirana-form');
