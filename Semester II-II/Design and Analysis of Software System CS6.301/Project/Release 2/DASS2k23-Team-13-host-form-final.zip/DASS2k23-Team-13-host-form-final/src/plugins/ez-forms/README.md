# Strapi plugin ez-forms

A quick description of ez-forms.
