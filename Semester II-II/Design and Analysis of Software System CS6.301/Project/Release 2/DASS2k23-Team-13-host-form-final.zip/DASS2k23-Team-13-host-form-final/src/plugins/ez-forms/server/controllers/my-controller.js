'use strict';

module.exports = ({ strapi }) => ({
  index(ctx) {
    ctx.body = strapi
      .plugin('ez-forms')
      .service('myService')
      .getWelcomeMessage();
  },
});
