'use strict';

module.exports = {
  default: {},
  validator() {},
};
