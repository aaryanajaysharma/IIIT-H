import React, { useState } from 'react';
import { useParams } from "react-router-dom";
import {
    FormControl,
    FormLabel,
    Input,
    Textarea,
    Button,
    useToast,
} from "@chakra-ui/react";
import axios from "axios"

export const FormGenerator = (props) => {
    // function FormGenerator({ formData }) {
    const [formState, setFormState] = useState({});
    const { mob } = useParams()

    console.log(props.formName)

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormState({ ...formState, [name]: value });
        // console.log(formState)
    };

    function printJSON(obj) {
        let str = '';
        for (let key in obj) {
            if (typeof obj[key] === 'object') {
                str += printJSON(obj[key]);
            } else {
                str += key + ': ' + obj[key] + '\n';
            }
        }
        return str;
    }

    const handleSubmit = (e) => {
        e.preventDefault();
        // console.log(formState);
        const updatedFormData = { ...formState, captain_id: mob };
        console.log(updatedFormData)
        const red = {
            "data": updatedFormData
        }
        console.log(red)
        axios.post('http://ec2-52-197-151-216.ap-northeast-1.compute.amazonaws.com:1337/api/' + props.formName + 's', red)
            .then(res => {
                // Handle the successful response
                console.log(res.data);
                let number = mob.replace(/[^\w\s]/gi, "").replace(/ /g, "");
		let url = `https://web.whatsapp.com/send?phone=${number}`;
                let url_mobile=`https://api.whatsapp.com/send?phone=${number}`;
                console.log(url)
                // Appending the message to the URL by encoding it
                let message = printJSON(formState)
                console.log(message)
                url += `&text=${encodeURI(message)}&app_absent=0`;
                url_mobile += `&text=${encodeURI(message)}&app_absent=0`;
                console.log(url)
                if (/Mobi/.test(navigator.userAgent)) {
                    window.open(url_mobile)
                  } else {
                    window.open(url);
                  }
	    })
            .catch(err => {
                // Handle the error response
                console.error(err);
                alert('Form submission failed.');
            });
        // TODO: submit form data to backend
    };
    const excludedFields = ['captain_id', 'createdAt', 'publishedAt', 'updatedAt'];
    const formFields = Object.keys(props.formData).filter((key) => !excludedFields.includes(key)).map((key) => (
        <div key={key}>
            <FormLabel htmlFor={key}>{key}</FormLabel>
            <Input
                type="text"
                name={key}
                id={key}
                value={formState[key] || ''}
                onChange={handleInputChange}
            />
        </div>
    ));

    return (
        <form onSubmit={handleSubmit}>
            {formFields}
            <Button type="submit">Submit</Button>
        </form>
    );
}

export default FormGenerator;
