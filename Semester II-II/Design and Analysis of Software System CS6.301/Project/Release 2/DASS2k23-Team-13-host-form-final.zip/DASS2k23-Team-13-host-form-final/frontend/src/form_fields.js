import { FormGenerator } from "./form_generator.js"
import { useState } from "react";
import axios from "axios"
import { useParams } from "react-router-dom";
import { useEffect } from "react";

export const FormFields = (props) => {

    const [formData, setFormData] = useState({});
    function printJSON(obj) {
        let str = '';
        for (let key in obj) {
            if (typeof obj[key] === 'object') {
                str += printJSON(obj[key]);
            } else {
                str += key + ': ' + obj[key] + '\n';
            }
        }
        return str;
    }
    console.log(props.formName)


    useEffect(() => {
        axios
            .get(
                `http://ec2-52-197-151-216.ap-northeast-1.compute.amazonaws.com:1337/api/` + props.formName + 's'
            )
            .then((response) => {
                console.log(response.data)
                setFormData(response.data.data[0].attributes)
            })
            .catch((error) => {
                console.log(error);
                // setFound(false);
            });
    }, [props.formName])

    // const handleSubmit = (e) => {
    //   e.preventDefault();
    //   // Submit the form data here
    //   // For example, you could use a third-party service like Formspree
    //   // and make a POST request to their API

    //   // toast({
    //   //   title: "Message sent",
    //   //   status: "success",
    //   //   duration: 5000,
    //   //   isClosable: true,
    //   // });
    //   const red = {
    //     "data": {
    //       "name": name,
    //       "date": date,
    //       "from": from,
    //       "to": to,
    //       "captain_id":mob
    //     }
    //   }
    //   console.log(red)


    //   axios.post('http://ec2-52-197-151-216.ap-northeast-1.compute.amazonaws.com:1337/api/trial-forms', red)
    //     .then(res => {
    //       // Handle the successful response
    //       console.log(res.data);
    //       let number = mob.replace(/[^\w\s]/gi, "").replace(/ /g, "");
    //       // console.log(number)

    //       // Appending the phone number to the URL
    //       let url = `https://web.whatsapp.com/send?phone=${number}`;
    //       console.log(url)
    //       // Appending the message to the URL by encoding it
    //       let message=printJSON(red.data)
    //       console.log(message)
    //       url += `&text=${encodeURI(message)}&app_absent=0`;
    //       console.log(url)
    //       // Open our newly created URL in a new tab to send the message
    //       window.open(url);
    //       // alert('Form submitted!');
    //       // Optionally redirect to another page
    //       // window.location.href = '/dashboard';
    //     })
    //     .catch(err => {
    //       // Handle the error response
    //       console.error(err);
    //       alert('Form submission failed.');
    //     });
    //   const handleSubmit = (e) => {
    //     e.preventDefault();

    //     axios.get('http://ec2-52-197-151-216.ap-northeast-1.compute.amazonaws.com:1337/api/shops')
    //       .then(response => {
    //         for (let i = 0; i < response.data.data.length; i++) {
    //           // console.log()
    //           if (response.data.data[i].attributes.rootshop === captain.rootshop) {
    //             console.log("Success")
    //             console.log(response.data.data[i])
    //             setFormName(response.data.data[i].attributes.form_name)
    //             setFormFound("true")
    //             // setCaptain(response.data.data[i].attributes);
    //             // console.log(response.data.data[i].attributes)
    //             // setFound(true);
    //           }
    //         }
    //       })
    //       .catch(err => {
    //         // Handle the error response
    //         console.error(err);
    //         alert('Rootshop not found');
    //       });


    //   };

    return (
        <>
            <FormGenerator formData={formData} formName={props.formName}></FormGenerator>
        </>
    );
}
