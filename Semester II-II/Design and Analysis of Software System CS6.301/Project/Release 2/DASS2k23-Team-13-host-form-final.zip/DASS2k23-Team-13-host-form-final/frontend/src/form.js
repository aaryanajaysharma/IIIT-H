import { useState } from "react";
import {
  FormControl,
  FormLabel,
  Input,
  Textarea,
  Button,
  useToast,
} from "@chakra-ui/react";
import axios from "axios"
import { useParams } from "react-router-dom";
import { useEffect } from "react";
import { FormFields } from "./form_fields.js"

export const Form = (props) => {
  const [found, setFound] = useState(false)
  const [formfound, setFormFound] = useState(false)
  const [captain, setCaptain] = useState("");
  const [formName, setFormName] = useState()
  const [formNames, setFormNames] = useState([])
  const [visibleFormIndex, setVisibleFormIndex] = useState(-1);
  const toast = useToast();
  // const { mobilenumber } = props;
  const { mob } = useParams()

  useEffect(() => {
    axios
      .get(
        `http://ec2-52-197-151-216.ap-northeast-1.compute.amazonaws.com:1337/api/captains`
      )
      .then((response) => {
        // console.log(response.data.data[0].attributes.user_login)
        // console.log(mob)
        for (let i = 0; i < response.data.data.length; i++) {
          // console.log()
          if (response.data.data[i].attributes.user_login === mob) {
            // console.log("Success")
            setCaptain(response.data.data[i].attributes);
            console.log(response.data.data[i].attributes)
            setFound(true);
          }
        }
      })
      .catch((error) => {
        console.log(error);
        setFound(false);
      });
  }, [mob])

  const handleSubmit = (e) => {
    e.preventDefault();
    let formNames = [];
    axios.get('http://ec2-52-197-151-216.ap-northeast-1.compute.amazonaws.com:1337/api/shops')
      .then(response => {
        for (let i = 0; i < response.data.data.length; i++) {
          // console.log()
          if (response.data.data[i].attributes.rootshop === captain.rootshop) {
            console.log("Success")
            console.log(response.data.data[i])
            formNames.push(response.data.data[i].attributes.form_name)
            setFormName(response.data.data[i].attributes.form_name)
            setFormFound("true")
          }
        }
        setVisibleFormIndex(0);
        setFormNames(formNames)
        // console.log(formNames)
      })
      .catch(err => {
        // Handle the error response
        console.error(err);
        alert('Rootshop not found');
      });


  };
  const handleFormToggle = (index) => {
    setVisibleFormIndex(index);
  };

  return (
    <>
      {found ? (
        <>
          <h1>{captain.display_name}</h1>
          <Button onClick={handleSubmit}>Form Search</Button>
          {formfound ?
            // formNames.map((name, index) => (
            //   <FormFields key={index} formName={name} />
            // ))
            <>
              {formNames.map((name, index) => (
                <div style={{ display: 'flex' }} key={index}>
                  <Button onClick={() => handleFormToggle(index)}>
                    {name}
                  </Button>
                  {visibleFormIndex === index && <FormFields formName={name} />}
                </div>
              ))}
              {visibleFormIndex === -1 && <p>Please select a form</p>}
            </>
            :
            <p>No form found</p>
          }
        </>
      )
        :
        (<p>Captain not Found</p>)}
    </>
  );
}
