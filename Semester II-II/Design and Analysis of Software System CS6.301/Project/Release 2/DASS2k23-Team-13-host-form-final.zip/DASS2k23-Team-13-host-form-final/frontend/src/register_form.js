import { useState } from "react";
import {
    FormControl,
    FormLabel,
    Input,
    Textarea,
    Button,
    useToast,
    Radio,
    Stack,
    RadioGroup
} from "@chakra-ui/react";
import axios from "axios"
import { useParams } from "react-router-dom";
import { useEffect } from "react";

export const RegisterForm = (props) => {
    const [name, setName] = useState("");
    const [email, setEmail] = useState("");
    const [shop_name, setShopName] = useState("");
    const [phone_number, setPhoneNumber] = useState("");

    const [found, setFound] = useState(false)
    const [captain, setCaptain] = useState("");
    const [rootshop, setRootshop] = useState("bakery");
    const toast = useToast();
    // const { mobilenumber } = props;

    function printJSON(obj) {
        let str = '';
        for (let key in obj) {
            if (typeof obj[key] === 'object') {
                str += printJSON(obj[key]);
            } else {
                str += key + ': ' + obj[key] + '\n';
            }
        }
        return str;
    }


    useEffect(() => {
        axios
            .get(
                `http://ec2-52-197-151-216.ap-northeast-1.compute.amazonaws.com:1337/api/captains`
            )
            .then((response) => {
                // console.log(response.data.data[0].attributes.user_login)
                // console.log(mob)
                for (let i = 0; i < response.data.data.length; i++) {
                    // console.log()
                    if (response.data.data[i].attributes.user_login === phone_number) {
                        // console.log("Success")
                        setCaptain(response.data.data[i].attributes);
                        console.log(response.data.data[i].attributes)
                        setFound(true);
                    }
                }
                // setCaptain(response.data);
                // console.log(response.data)
                // setFound(true);
            })
            .catch((error) => {
                console.log(error);
                setFound(false);
            });
    }, [phone_number]);

    const handleSubmit = (e) => {
        e.preventDefault();
        // Submit the form data here
        // For example, you could use a third-party service like Formspree
        // and make a POST request to their API

        // toast({
        //   title: "Message sent",
        //   status: "success",
        //   duration: 5000,
        //   isClosable: true,
        // });
        const validPhone = /^\d{10}$/;
        if (!phone_number.match(validPhone)) {
            alert("Please enter a valid 10 digit phone number");
            return;
        }
        const red = {
            "data": {
                "user_login": phone_number,
                "user_nicename": name,
                "user_email": email,
                "user_url": phone_number,
                "display_name": shop_name,
                "rootshop":rootshop
            }
        }
        console.log(red)


        axios.post('http://ec2-52-197-151-216.ap-northeast-1.compute.amazonaws.com:1337/api/captains', red)
            .then(res => {
                // Handle the successful response
                console.log(res.data);
                alert('Captain registered!');
                // Optionally redirect to another page
                // window.location.href = '/dashboard';
            })
            .catch(err => {
                // Handle the error response
                console.error(err);
                alert('Form submission failed.');
            });


    };

    return (
        <>
            {/* <h1>{mob}</h1> */}

            {!found ? (<>
                <h1>{captain.display_name}</h1>
                <form onSubmit={handleSubmit}>
                    <FormControl id="name" isRequired>
                        <FormLabel>Captain's Name</FormLabel>
                        <Input
                            type="text"
                            placeholder="Enter your name"
                            value={name}
                            onChange={(e) => setName(e.target.value)}
                        />
                    </FormControl>

                    <FormControl id="email" isRequired>
                        <FormLabel>Email</FormLabel>
                        <Input
                            type="email"
                            placeholder="Enter your email id"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                        />
                    </FormControl>

                    <FormControl id="Shop Name" isRequired>
                        <FormLabel>Shop Name</FormLabel>
                        <Textarea
                            placeholder="Enter the name of your shop"
                            value={shop_name}
                            onChange={(e) => setShopName(e.target.value)}
                        />
                    </FormControl>

                    <FormControl id="rootshop" isRequired>
                        <FormLabel>Rootshop</FormLabel>
                        <RadioGroup  onChange={setRootshop} value={rootshop}>
                            <Stack direction="row">
                                <Radio value="bakery">Bakery</Radio>
                                <Radio value="vegetable shop">Vegetable Shop</Radio>
                                <Radio value="kirana">Kirana</Radio>
                                <Radio value="pharmacy">Pharmacy</Radio>
                            </Stack>
                        </RadioGroup>
                    </FormControl>


                    <FormControl id="Phone Number" isRequired>
                        <FormLabel>Phone Number</FormLabel>
                        <Textarea
                            placeholder="Enter your 10 digit phone number"
                            value={phone_number}
                            onChange={(e) => setPhoneNumber(e.target.value)}
                        />
                    </FormControl>

                    <Button mt={4} colorScheme="blue" type="submit">
                        Register
                    </Button>
                </form></>) : (<p>Captain exists Already</p>)}
        </>
    );
}
