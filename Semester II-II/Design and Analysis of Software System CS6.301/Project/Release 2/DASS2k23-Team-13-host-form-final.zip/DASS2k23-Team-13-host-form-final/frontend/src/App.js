import * as React from 'react'
import {Form} from './form.js'
import {RegisterForm} from './register_form.js'
// 1. import `ChakraProvider` component
import { ChakraProvider } from '@chakra-ui/react'
import {useParams} from 'react-router-dom'
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";

export const App=()=> {
  const { mobilenumber } = useParams();
  // 2. Wrap ChakraProvider at the root of your app
  return (
    <Router>
    <ChakraProvider>
    <div className="App">
      {/* {form === 'login' ? <Login SwitchForm={SwitchForms} /> : <Register SwitchForm={SwitchForms}/>} */}
      <Routes>
        {/* <Route path='/auth' element={form === 'login' ? <Login SwitchForm={SwitchForms} /> : <Register SwitchForm={SwitchForms}/>}/> */}
        <Route path='/:mob' element={<Form />}/>
        <Route path='/register' element={<RegisterForm />}/>
      </Routes>
    </div>
    
    </ChakraProvider>
    </Router>
  )
}