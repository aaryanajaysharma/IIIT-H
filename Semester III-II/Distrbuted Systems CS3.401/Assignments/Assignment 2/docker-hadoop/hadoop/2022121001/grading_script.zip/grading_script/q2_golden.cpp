#include <bits/stdc++.h>

using namespace std;

int main() {
    map<int, vector<int>> adj;
    string str;
    while (getline(cin, str)) {
        stringstream ss(str);
        array<int, 2> nodes;
        for (int i = 0; i < 2; i++) ss >> nodes[i];
        adj[nodes[0]].push_back(nodes[1]);
        adj[nodes[1]].push_back(nodes[0]);
    }
    map<pair<int, int>, vector<int>> friends;
    for (auto &[k, v]: adj) {
        if (v.size() > 1) {
            sort(v.begin(), v.end());
            for (int p = 0; p < v.size(); p++)
                for (int q = p + 1; q < v.size(); q++)
                    friends[{v[p], v[q]}].push_back(k);
        }
    }
    for (auto &[k, v]: friends) {
        sort(v.begin(), v.end());
        cout << k.first << " " << k.second << "\t" << v[0];
        for (int i = 1; i < v.size(); i++) cout << " " << v[i];
        cout << "\n";
    }
    return 0;
}
