#!/bin/bash

# Usage: ./evaluate.sh <TESTS_DIR> <SUBMISSION_DIR> <ROLL_NUMBER>

TESTS_DIR="$1"
SUBMISSION_DIR="$2"
ROLL_NUMBER="$3"
INDEX="$4"

# Change to the submission directory
cd "$SUBMISSION_DIR" || { echo "Error: Failed to change directory to $SUBMISSION_DIR for roll number $ROLL_NUMBER" >&2; exit 0; }

# Check if the file "runner-script" or "runner_script" exists
SCRIPT="runner-script"
if [ ! -f "runner-script" ]; then
	if [ ! -f "runner_script" ]; then
	    echo "Error: The 'runner-script' file is missing for roll number $ROLL_NUMBER" >&2
	    exit 0
	else
	    SCRIPT="runner_script"
	fi
fi

# Provide execute permissions to the "runner-script" file
#chmod +x "$SCRIPT"
chmod +x ./*

# Run "make build" command (ignore errors)
make build 2>/dev/null

# Initialize score
score=0

# Loop through each test directory in the tests directory
for test_dir in "$TESTS_DIR"/*/; do
    # Get the test index from the directory name
    test_index=$(basename "$test_dir")

    # Remove existing "in" and "out" directories in HDFS
    hdfs dfs -rm -r "$INDEX"'in*' "$INDEX"'out*' 2>/dev/null

    # Run the runner script with the current test directory input
    ./"$SCRIPT" /usr/local/apps/hadoop-3.3.0/share/hadoop/tools/lib/hadoop-streaming-3.3.0.jar "$test_dir" "$INDEX"in "$INDEX"out > /dev/null 2>&1

    # Check if "out" directory contains at least three "part-*" files
    if [[ $(hdfs dfs -ls "$INDEX"'out/part-*' 2>/dev/null | wc -l) -ge 3 ]]; then
        # Concatenate all the output files in HDFS
        hdfs dfs -cat "$INDEX"'out/part-*' > output.txt

        # Sort the lines in the output file
        sort output.txt > sorted_output.txt

        # Sort the lines in the expected output file
        sort "$test_dir/../$test_index.out" > sorted_expected.txt

        # Compare the sorted output with the sorted expected output
        if diff -Z sorted_output.txt sorted_expected.txt >/dev/null; then
            score=$((score + 1))
        else
            echo "Error: Output mismatch for test $test_index and roll number $ROLL_NUMBER" >&2
        fi

        # Clean up temporary files
        rm output.txt sorted_output.txt sorted_expected.txt
    else
        echo "Error: The 'out' directory should contain at least three 'part-*' files for roll number $ROLL_NUMBER" >&2
    fi
    echo "Test: ${test_index} done"
done

# Return the final score
exit $score
