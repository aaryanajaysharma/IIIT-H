import os
import subprocess
import zipfile
import tarfile
import shutil
import csv
import sys

SUBMISSIONS_DIRECTORY = "all_subs/folder" + sys.argv[1]
TESTS_DIRECTORY = "tests"
SCORE_FILE = "score" + sys.argv[1] + ".csv"
EVALUATION_SCRIPT = "evaluate.sh"


def extract_file(file_path, destination_dir):
    if file_path.endswith(".zip"):
        with zipfile.ZipFile(file_path, 'r') as zip_ref:
            zip_ref.extractall(destination_dir)
    elif file_path.endswith(".tar"):
        with tarfile.open(file_path, 'r') as tar_ref:
            tar_ref.extractall(destination_dir)
    elif file_path.endswith(".tar.gz") or file_path.endswith(".tgz"):
        with tarfile.open(file_path, 'r:gz') as tar_ref:
            tar_ref.extractall(destination_dir)
    else:
        raise Exception(f"Unsupported file format: {file_path}")


def evaluate_question(question_dir, submission_dir, roll_number):
    # Run the bash script for evaluation
    result = subprocess.run(["bash", EVALUATION_SCRIPT, os.path.abspath(question_dir), os.path.abspath(submission_dir), roll_number, sys.argv[1]], capture_output=True, text=True)

    # Get the score from the return code of the bash script
    score = result.returncode

    # Print the captured error messages, if any
    if result.stderr:
        print(f"Error messages for roll number {roll_number}:")
        print(result.stderr)

    if result.stdout:
        print(f"Debug messages for roll number {roll_number}:")
        print(result.stdout)

    return score


def process_submission(submission_dir):
    try:
        compressed_file = None
        for file in os.listdir(submission_dir):
            if file.endswith((".zip", ".tar", ".tar.gz", ".tgz")):
                compressed_file = file
                break

        if compressed_file is None:
            raise Exception(f"No valid compressed file found in directory: {submission_dir}")

        roll_number = os.path.splitext(compressed_file)[0]

        # Validate the roll number
        if not roll_number.isdigit() or len(roll_number) != 10:
            raise Exception(f"Invalid roll number: {roll_number}")

        # Extract the compressed file
        extract_file(os.path.join(submission_dir, compressed_file), submission_dir)

        # Remove the compressed file
        os.remove(os.path.join(submission_dir, compressed_file))

        # Remove the "__MACOSX" directory if it exists
        macosx_dir = os.path.join(submission_dir, "__MACOSX")
        if os.path.isdir(macosx_dir):
            shutil.rmtree(macosx_dir)

        # Check if the extracted content is inside a single directory
        extracted_content = os.listdir(submission_dir)
        if len(extracted_content) == 1 and os.path.isdir(os.path.join(submission_dir, extracted_content[0])):
            # Move the contents of the inner directory to the submission directory
            inner_directory = os.path.join(submission_dir, extracted_content[0])
            for item in os.listdir(inner_directory):
                shutil.move(os.path.join(inner_directory, item), submission_dir)
            # Remove the empty inner directory
            os.rmdir(inner_directory)

        # Rename the directory to the roll number
        new_dir_name = os.path.join(os.path.dirname(submission_dir), roll_number)
        os.rename(submission_dir, new_dir_name)

        submission_dir = new_dir_name

        # Evaluate question 2
        q2_dir = os.path.join(submission_dir, "q2")
        q2_score = evaluate_question(os.path.join(TESTS_DIRECTORY, "q2"), q2_dir, roll_number) if os.path.isdir(q2_dir) else 0

        # Evaluate question 3
        q3_dir = os.path.join(submission_dir, "q3")
        q3_score = evaluate_question(os.path.join(TESTS_DIRECTORY, "q3"), q3_dir, roll_number) if os.path.isdir(q3_dir) else 0

        # Write the scores to the CSV file
        with open(SCORE_FILE, 'a', newline='') as file:
            writer = csv.writer(file)
            writer.writerow([roll_number, q2_score, q3_score])

        print(f"Finished {roll_number} with score: {q2_score} {q3_score}")


    except Exception as e:
        print(f"Error processing submission: {submission_dir}", file=sys.stderr)
        print(f"Error message: {str(e)}", file=sys.stderr)


if __name__ == "__main__":
    # Create the CSV file and write the header
    with open(SCORE_FILE, 'w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(['ID Number', 'Q2', 'Q3'])

    for item in os.listdir(SUBMISSIONS_DIRECTORY):
        item_path = os.path.join(SUBMISSIONS_DIRECTORY, item)
        if os.path.isdir(item_path):
            process_submission(item_path)
