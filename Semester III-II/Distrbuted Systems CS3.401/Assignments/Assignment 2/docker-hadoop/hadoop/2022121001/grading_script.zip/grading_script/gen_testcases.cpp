#include <numeric>
#include "testlib.h"

using namespace std;

const int MAX_FILES = 15;
#define Q3 1

int main(int argc, char *argv[]) {
    registerGen(argc, argv, 1);

    int n = opt<int>("n");
    int value_bias = opt<int>("value-bias", 0);
    int mode = opt<int>("mode", 0);

    vector<pair<int, int>> rem;
    for (int u = 1; u <= n; u++) for (int v = u + 1; v <= n; v++) rem.emplace_back(u, v);
    shuffle(rem.begin(), rem.end());

    int pick = rnd.wnext(1, n * (n - 1) / 2, value_bias);
    int num_files = rnd.next(1, min(MAX_FILES, pick));
    auto sizes = rnd.partition(num_files, pick);
    int cnt = 0;
    vector<vector<int>> nodes(n + 1);
    vector<int> order(n);
    iota(order.begin(), order.end(), 1);
    shuffle(order.begin(), order.end());
    if (mode == Q3) {
        for (int i = 0; i < pick; i++) {
            nodes[rem[i].first].emplace_back(rem[i].second);
            nodes[rem[i].second].emplace_back(rem[i].first);
        }
        for (int i = 1; i <= n; i++) {
            if (!nodes[i].empty()) continue;
            int to = rnd.next(1, n);
            while (to == i) to = rnd.next(1, n);
            nodes[i].emplace_back(to);
            nodes[to].emplace_back(i);
        }
        num_files = rnd.next(1, min(MAX_FILES, n));
        sizes = rnd.partition(num_files, n);
    }

    for (int i = 0; i < num_files; i++) {
        std::ofstream outfile(to_string(i) + ".in", std::ios_base::app);
        while (sizes[i]--) {
            if (mode != Q3) {
                outfile << rem[cnt].first << " " << rem[cnt].second << "\n";
                cnt++;
            } else {
                int u = order[cnt++];
                outfile << u << "\t";
                outfile << nodes[u][0];
                for (int j = 1; j < nodes[u].size(); j++) outfile << " " << nodes[u][j];
                outfile << "\n";
            }
        }
        outfile.close();
    }

    return 0;
}