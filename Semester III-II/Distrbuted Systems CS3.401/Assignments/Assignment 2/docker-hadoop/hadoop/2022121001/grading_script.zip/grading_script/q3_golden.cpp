#include <bits/stdc++.h>

using namespace std;

const int INF = 11;

int main() {
    map<int, vector<int>> adj;
    string str;
    while (getline(cin, str)) {
        stringstream ss(str);
        string k, v;
        getline(ss, k, '\t');
        getline(ss, v, '\t');
        stringstream friends(v);
        int node;
        int u = stoi(k);
        while (friends >> node) adj[u].push_back(node);
    }
    queue<int> q;
    int n = adj.size();
    vector<int> dist(n + 1, INF);
    dist[1] = 0;
    q.push(1);
    while (!q.empty()) {
        int fr = q.front();
        q.pop();
        for (auto &to: adj[fr]) {
            if (dist[fr] + 1 < dist[to] and dist[fr] + 1 < INF) {
                dist[to] = dist[fr] + 1;
                q.push(to);
            }
        }
    }
    for (int i = 1; i <= n; i++) if (dist[i] < INF) cout << i << "\t" << dist[i] << "\n";
    return 0;
}
